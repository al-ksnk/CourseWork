﻿using CourseWork.Models;
using Microsoft.EntityFrameworkCore;

namespace CourseWork
{
	public class ApplicationContext : DbContext
	{
		public DbSet<Player> Players { get; set; }
		public DbSet<Game> Games { get; set; }
		public DbSet<Tournament> Tournaments { get; set; }
		public DbSet<Figure> Figures { get; set; }
		public ApplicationContext(DbContextOptions<ApplicationContext> options)
		    : base(options)
		{
			Database.EnsureCreated();
		}
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<Game>()
				.HasOne(g => g.Tournament)
				.WithMany(t => t.Games);

			modelBuilder.Entity<Figure>().HasData(
				new { Id = 1, Name = "king", Position = "e1, e8", Movement = "exactly one square horizontally, vertically, or diagonally", Value = 100 },
				new { Id = 2, Name = "queen", Position = "d1, d8", Movement = "any number of vacant squares horizontally, vertically, or diagonally", Value = 9 },
				new { Id = 3, Name = "rook", Position = "a1, h1, a8, h8", Movement = "any number of vacant squares horizontally or vertically", Value = 5 },
				new { Id = 4, Name = "bishop", Position = "c1, f1, c8, f8", Movement = "any number of vacant squares diagonally", Value = 3 },
				new { Id = 5, Name = "knight", Position = "b1, g1, b8, g8", Movement = "to one of the nearest squares not on the same rank, file, or diagonal", Value = 3 },
				new { Id = 6, Name = "pawn", Position = "2 and 7 row", Movement = "straight forward one square, if that square is vacant", Value = 1 });

			modelBuilder.Entity<Player>().HasData(
				new
				{
					Id = 1,
					Age = 31,
					Country = "Norwey",
					Name = "Magnus Carlsen",
					Rating = 2847,
					Title = "Grandmaster"
				},
				new
				{
					Id = 2,
					Age = 29,
					Country = "United States",
					Name = "Fabiano Caruana",
					Rating = 2820,
					Title = "Grandmaster"
				},
				new
				{
					Id = 3,
					Age = 35,
					Country = "Ukraine",
					Name = "Alexander Areshchenko",
					Rating = 2720,
					Title = "Grandmaster"
				},
				new
				{
					Id = 4,
					Age = 19,
					Country = "France",
					Name = "Alireza Firouzja",
					Rating = 2759,
					Title = "Grandmaster"
				},
				new
				{
					Id = 5,
					Age = 35,
					Country = "Ukraine",
					Name = "Yuriy Kryvoruchko",
					Rating = 2699,
					Title = "Grandmaster"
				},
				new
				{
					Id = 6,
					Age = 30,
					Country = "United States",
					Name = "Sam Shankland",
					Rating = 2691,
					Title = "Grandmaster"
				},
				new
				{
					Id = 7,
					Age = 27,
					Country = "Russia",
					Name = "Vladimir Fedoseev",
					Rating = 2696,
					Title = "Grandmaster"
				});


			modelBuilder.Entity<Tournament>().HasData(
				new
				{
					Id = 1,
					Name = "World Cup 2021",
					Place = "Kiyv",
					Prize = "1,892,500",
					StartDate = DateTime.Now,
					EndDate = DateTime.Now,
					Type = "classical"
				});

			modelBuilder.Entity<Game>().HasData(
				new
				{
					Id = 1,
					Name = "Third round",
					Place = "Sochi",
					StartDate = DateTime.Now,
					Type = "classical",
					WinnerName = "Sam Shankland",
					MoveCount = 23,
					TournamentId = 1,
					WhitePlayerId = 3,
					BlackPlayerId = 6
				},
				new
				{
					Id = 2,
					Name = "Third place",
					Place = "Sochi",
					StartDate = DateTime.Now,
					Type = "classical",
					WinnerName = "Magnus Carlsen",
					MoveCount = 42,
					TournamentId = 1,
					WhitePlayerId = 7,
					BlackPlayerId = 1
				});

			modelBuilder.Entity<Game>()
				.HasMany(g => g.Players)
				.WithMany(p => p.Games)
				.UsingEntity(j => j.HasData(
					new { GamesId = 1, PlayersId = 3 },
					new { GamesId = 1, PlayersId = 6 },
					new { GamesId = 2, PlayersId = 1 },
					new { GamesId = 2, PlayersId = 7 }
					));

		}
	}
}
