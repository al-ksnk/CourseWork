﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CourseWork;
using CourseWork.Models;

namespace CourseWork.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class FiguresController : ControllerBase
	{
		private readonly ApplicationContext _context;

		public FiguresController(ApplicationContext context)
		{
			_context = context;
		}

		// GET: api/Figures
		[HttpGet]
		public async Task<ActionResult<IEnumerable<Figure>>> GetFigures()
		{
			if (_context.Figures == null)
			{
				return NotFound();
			}

			return await _context.Figures.ToListAsync();
		}

		// GET: api/Figures/5
		[HttpGet("{id}")]
		public async Task<ActionResult> GetFigure(int id)
		{
			if (_context.Figures == null)
			{
				return NotFound();
			}

			var figure = _context.Figures.Single(g => g.Id == id);

			if (figure == null)
			{
				return NotFound();
			}

			return Ok(figure);
		}
	}
}
