﻿namespace CourseWork.Models
{
	public class EFModel
	{
		public int Id { get; set; }
		public string Name { get; set; }

	}
}
