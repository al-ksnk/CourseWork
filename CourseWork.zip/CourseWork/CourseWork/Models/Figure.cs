﻿namespace CourseWork.Models
{
	public class Figure : EFModel
	{
		public string Movement { get; set; }
		public string Position { get; set; }
		public int Value { get; set; }
	}
}
