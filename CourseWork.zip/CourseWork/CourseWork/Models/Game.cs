﻿namespace CourseWork.Models
{
	public class Game: EFModel
	{
		public string Place { get; set; }
		public DateTime StartDate { get; set; }
		public string Type { get; set; }
		public string WinnerName { get; set; }
		public int MoveCount { get; set; }


		public int TournamentId { get; set; }
		public Tournament Tournament { get; set; }


		public int WhitePlayerId { get; set; }
		public int BlackPlayerId { get; set; }
		public virtual ICollection<Player> Players { get; set; } = new List<Player>();
	}
}
