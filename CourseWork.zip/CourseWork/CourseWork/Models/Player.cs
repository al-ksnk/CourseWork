﻿namespace CourseWork.Models
{

	public class Player : EFModel
	{
		public int Age { get; set; }
		public string Country { get; set; }
		public string Title { get; set; }
		public int Rating { get; set; }

		public virtual ICollection<Game> Games { get; set; } = new List<Game>();

 
		public string ChangeName(string newName)
		{
			Name = newName;

			return "Ok, name changed";
		}

		public string AddRating(int ratingToAdd)
		{
			Rating = (short)(Rating + ratingToAdd);

			return $"Successfully add rating to {Id} player";
		}
	}

}
