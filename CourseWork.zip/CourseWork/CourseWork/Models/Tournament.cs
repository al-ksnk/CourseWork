﻿namespace CourseWork.Models
{
	public class Tournament : EFModel
	{
		public string Place { get; set; }
		public DateTime StartDate { get; set; }
		public DateTime EndDate { get; set; }
		public string Prize { get; set; }
		public string Type { get; set; }

		public ICollection<Game> Games { get; set; } = new List<Game>();

	
	}
}
